import os, time, os.path, random , glob, sys, re,datetime
import pytz , functools, itertools, math

_FORMAT = r"%a %b %d %H:%M:%S %Y"

#kwresult is always last and it's dict
def getargs(options, kwoptions={}, split="="):
    result = [ de for de,fn in options]
    #print(kwoptions)
    kwresult = {}
    index = 0
    for i,value in enumerate(sys.argv[1:]):
        if value.count(split) >= 1:
            #got kw value 
            k,v =  value.split(split)
            if v.lower().strip() in kwoptions.get(k.lower().strip(), ()):
                kwresult[k.lower().strip()] = v.lower().strip()
            continue
        result[index] = options[index][-1](value)
        index += 1
    #print(result, kwresult)
    return [*result, kwresult] if kwoptions else result


class Value:
    def next(*args):
        raise NotImplementedError("Implement this")
    def __str__(self):
        return f"{self.__class__.__name__}({self.__dict__})"

class IntValue(Value):
    def __init__(self, min=0, max=100):
        self.max = max
        self.min = min
    def next(self, *args):
        return random.randint(self.min, self.max)

class MonotonicValue(Value):
    def __init__(self, min=0, max=100, mul=0.1, *, current=None, step=None, convert_fn, final_fn):
        self.max = max
        self.min = min
        self.current = current if current is not None else min
        self.delta = abs(max-min)*mul if step is None else step 
        self.convert_fn = convert_fn
        self.final_fn = final_fn         
    def next(self, *args):
        self.current = self.convert_fn(self.current, self.delta)
        return self.final_fn(self.current, self.min, self.max)

class IncreasingIntValue(MonotonicValue):
    def __init__(self, min=0, max=100, mul=0.1):
        super().__init__(min, max, mul, current=min,
                        convert_fn = lambda current,delta: current + random.randint(0, int(delta)),
                        final_fn = lambda current, min, max:  int(current if current <= max else max))     

class DecreasingIntValue(MonotonicValue):
    def __init__(self, min=0, max=100, mul=0.1):
        super().__init__(min, max, mul, current=max,
                        convert_fn = lambda current,delta: current - random.randint(0, int(delta)),
                        final_fn = lambda current, min, max:  int(current if current >= min else min))

class IncreasingStepFloatValue(MonotonicValue):
    def __init__(self, min=0, max=1, step=0.01):
        super().__init__(min, max, step=0.01, current=min,
                        convert_fn = lambda current,delta: round(current + delta, math.ceil(math.log10(1/0.09))) ,
                        final_fn = lambda current, min, max:  current if current <= max else max)     

        
        
class FnValue(Value):
    def __init__(self, fn, **kwargs):
        self.kwargs = kwargs
        self.fn = fn 
    def next(self, *args, fn=None):           
        return fn(*args, **self.kwargs) if fn is not None else self.fn(*args, **self.kwargs)


class ConstantValue(Value):
    def __init__(self, *args):
        self.args = args 
    def next(self, *args):
        return args[0] if len(args) >= 1 else self.args[0] if len(self.args) >=1  else ''
        
class TimestampValue(Value):
    def __init__(self, format=_FORMAT):
        self.format = format
    def next(self, *args):
        return datetime.datetime.strptime(args[0], self.format).timestamp()
        
class CurrentDatetimeValue(Value):
    def __init__(self, format=_FORMAT, tz=pytz.timezone('Asia/Kolkata')):
        self.format = format
        self.tz = tz
    def next(self, *args):
        return datetime.datetime.now(self.tz).strftime(self.format)
        
class IteratorValue(Value):
    def __init__(self, it, fn=lambda e: e):
        self.it = itertools.cycle(it)
        self.fn = fn 
    def next(self, *args):        
        return self.fn(next(self.it))
    
class FloatValue(Value):
    def __init__(self, min=0, max=100, mul=0.1):
        self.max = int(max)
        self.min = int(min)
        self.mul = mul
    def next(self, *args):
        return random.randint(self.min, self.max) * self.mul
        
class ChoiceValue(Value):
    def __init__(self, *ch):
        self.choices = ch
    def next(self, *args):
        return random.choice(self.choices)
    
class Template:
    def __init__(self, template, values):
        self.template = template
        self.values = values
    def get_string(self, tm=None, tm_seperator=None, *args):
        #print(f"""tm={tm}, {self.template}, {[str(v) for v in self.values]}""")
        res = ""
        if tm is not None :
            res += tm + tm_seperator 
        res +=  self.template % tuple([ v.next(*args) for v in self.values])
        return res 
            


def get_template_string(templates, *args, tm=None, tm_seperator=" "):
    res = ""
    for t in templates:
        res += t.get_string(tm, tm_seperator, *args)
    return res

#days=0, seconds=0, microseconds=0, milliseconds=0, minutes=0, hours=0, weeks=0
def get_time(count, before, format=_FORMAT, tz=pytz.timezone('Asia/Kolkata')): #before is dict
    #Check first
    try:
        datetime.timedelta(**{before: 1})
    except:
        before = "days"
    delta = datetime.timedelta(**{before: 1})    
    start = datetime.datetime.now(tz) - datetime.timedelta(**{before: count})
    #print(delta, start)
    return [ (start + i*delta).astimezone(tz).strftime(format)  for i in range(count)]
    
   
    
def getfilename(path, fileglob):
    def getfilepatterns(pattern, options=("(\\d+)", "%d"), index=1):
        """given 'price*.log' returns 'price(\\d+).log', 'price%d.log'"""
        parts = pattern.split("*")
        results = [parts.copy() for e in options]
        for i,e in enumerate(options):
            results[i][index:index] = options[i]
        return ["".join(res) for res in results]
    filepattern, filenametemplate = getfilepatterns(fileglob)
    nos = []
    for file in glob.glob(os.path.join(path, fileglob)):
        fname = os.path.basename(file)
        no = re.findall(filepattern, fname)
        nos.append(int(no[0]))
    maxno= max(nos) if nos else 0
    return filenametemplate % (maxno+1, )

    
"""
%m/%d/%Y 	    06/05/2013
%A, %B %e, %Y 	Sunday, June 5, 2013
%b %e %a 	    Jun 5 Sun

%H:%M 	        23:05
%I:%M %p 	    11:05 PM

%a 	Sun 	Weekday
%A 	Sunday 	 
%w 	0..6 (Sunday is 0) 	
 
%y 	13 	Year
%Y 	2013 	 

%b 	Jan 	Month
%B 	January 	 
%m 	01..12 	 

%d 	01..31 	Day
%e 	1..31 	

%l 	1 	    Hour
%H 	00..23 	24h Hour
%I 	01..12 	12h Hour

%M 	00..59 	Minute
%S 	00..60 	Second

%p 	AM 	    AM or PM

%j 	001..366 	Day of the year
%% 	% 	Literal % character

%f Microsecond as a decimal number, zero-padded on the left.

%z UTC offset in the form ±HHMM[SS[.ffffff]] (empty string if the object is naive).
%Z Time zone name (empty string if the object is naive).

Parsing, datetime.strptime(date_string, format)
printing  datetime.strftime(format)

import pytz 
pytz.common_timezones  to see all the time zone eg Asia/Kolkata

store datetimes in UTC and convert on display.

utc_now = pytz.utc.localize(datetime.datetime.utcnow())
pst_now = utc_now.astimezone(pytz.timezone("America/Los_Angeles"))

pst_now == utc_now
> True

from pytz import timezone
>>> import pytz
>>> utc = pytz.utc
>>> eastern = timezone('US/Eastern')
>>> utc_dt = datetime(2002, 10, 27, 6, 0, 0, tzinfo=utc) # or datetime.utcnow()
>>> loc_dt = utc_dt.astimezone(eastern)
>>> loc_dt.strftime(fmt)
'2002-10-27 01:00:00 EST-0500'

"""
