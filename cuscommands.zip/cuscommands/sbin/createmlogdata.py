from common import *
import os.path 

#args : Count: how many data points , "days": how fat back from current time 
# defaults = ( (default, convertion fn), ...)
OPTIONS = ( (10, int), ("days", str),)
FILEGLOB ="metricevents*.log"
PATH = os.path.join(os.path.dirname(__file__), "..", "mlogs")

#08-05-2017 20:26:29.075-0700
FORMAT=r"%m-%d-%Y %H:%M:%S.%f%z"

template1 = Template(template="""NFO Metrics - group=queue, location=sf, corp=splunk, name=%s, max_size_kb=%d, current_size_kb=%d, current_size=%d, largest_size=%d, smallest_size=%d\n""", 
      values=[ChoiceValue("udp_queue", "aggqueue", "auditqueue"),
                ChoiceValue(1024,2048,4096),
                ChoiceValue(0,128,512),                
                IntValue(min=0,max=10),
                IntValue(min=20,max=50),
                IntValue(min=0,max=20),
                ])
                
template2 = Template(template="""INFO Metrics - group=pipeline, name=indexerpipe, processor=%s, cpu_seconds=%d, executes=%d, cumulative_hits=%d""", 
      values=[ChoiceValue("indexin", "index_thruput", "indexandforward"),          
                IntValue(min=0,max=5),
                IntValue(min=100,max=200),
                CummulativeIntValue(min=1000000,max=3000000),
                ])
                
TEMPLATES= [ template1, template2]


    

if __name__ == '__main__':
    COUNT, BEFORE = getargs(OPTIONS)    
    filename = os.path.join(PATH, getfilename(PATH,FILEGLOB))
    with open(filename, "at") as f:
        print(f"Writing to {filename}")
        for i in get_time(count=COUNT, before=BEFORE,format=FORMAT):
            txt = get_template_string(TEMPLATES, tm=i)
            print(txt, file=f)