from common import *
import os.path 

#args : Count: how many data points , "seconds": how fat back from current time 
# defaults = ( (default, convertion fn), ...)
OPTIONS = ( (10, int), ("seconds", str),)
FILEGLOB ="price*.log"
PATH = os.path.join(os.path.dirname(__file__), "..", "logs")

#Sun Dec 20 20:16:27 2020
FORMAT=r"%a %b %d %H:%M:%S %Y"

template1 = Template(template="""Info: sold product %s with price %3.2f sold to user %s aged %d\n""", 
      values=[ChoiceValue("shirt", "pant", "ball", "bat"),
                FloatValue(min=100,max=900),
                ChoiceValue("martin", "jack999", "jim", "teen"),
                IntValue(min=18,max=50)
                ])
                
template2 = Template(template="""Info: error %d in selling product %s""", 
      values=[ChoiceValue(50,100,200,500,503,202),
                ChoiceValue("shirt", "pant", "ball", "bat")               
                ])               
                
TEMPLATES= [ template1, template2]



    

    

if __name__ == '__main__':
    COUNT, BEFORE = getargs(OPTIONS)    
    filename = os.path.join(PATH, getfilename(PATH,FILEGLOB))
    with open(filename, "at") as f:
        print(f"Writing to {filename}")
        for i in get_time(count=COUNT, before=BEFORE,format=FORMAT):
            txt = get_template_string(TEMPLATES, tm=i)
            print(txt, file=f)