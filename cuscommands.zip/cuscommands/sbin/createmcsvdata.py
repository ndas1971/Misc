from common import *
import os.path 

#args : Count: how many data points , "days": how fat back from current time 
# defaults = ( (default, convertion fn), ...)
OPTIONS = ( (10, int), ("days", str))
KWOPTIONS = { 'style' : ( 'single', 'multiple' ),  }

FILEGLOB ="metrice*.csv"
PATH = os.path.join(os.path.dirname(__file__), "..", "mlogs")

#corresponding to KWOPTIONS['style']
HEADERS= {
'single': '"metric_timestamp","metric_name","_value","dc","host"',
'multiple': '"_time","metric_name:cpu.usr","metric_name:cpu.sys","metric_name:cpu.idle","dc","host"',
}


tm = TimestampValue()
d1 = ChoiceValue("east", "west", "north", "south")
d2 = ChoiceValue("host1.splunk.com", "host2.splunk.com", "host3.splunk.com")

template1 = Template(template='"%d",%3.2f,%3.2f,%3.2f,"%s","%s"', 
      values=[tm,
                FloatValue(min=10,max=30),
                FloatValue(min=10,max=30),            
                FloatValue(min=10,max=30),
                d1,
                d2,
                ])
                
template2 = Template(template='"%d","%s",%3.2f,"%s","%s"', 
      values=[tm,
                ChoiceValue("cpu.usr", "cpu.sys", "cpu.idle"),          
                FloatValue(min=10,max=30),
                d1,
                d2,
                ])
                

if __name__ == '__main__':
    COUNT, BEFORE, STYLE = getargs(OPTIONS, KWOPTIONS)
    style = STYLE.get('style', 'single')    
    TEMPLATES= [ template2 if  style == 'single' else template1]
    filename = os.path.join(PATH, getfilename(PATH,FILEGLOB))
    with open(filename, "at") as f:
        print(f"Writing to {filename}")
        print(HEADERS[style], file=f)
        for t in get_time(count=COUNT, before=BEFORE):
            txt = get_template_string(TEMPLATES,t)
            print(txt, file=f)