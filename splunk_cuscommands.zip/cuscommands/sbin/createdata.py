import os, time, os.path, random , glob, sys, re,datetime

# defaults = ( (default, convertion fn), ...)
options = ( (10, int), ("seconds", str),)

def getargs(options):
    result = [ de for de,fn in options]
    for i,value in enumerate(sys.argv[1:]):
        result[i] = options[i][-1](value)
    return result    

template = lambda tm, product="shirt", price=200.3, user="martin", age=20,\
    errorcode=50: """%s Info: sold product %s with price %3.2f sold to user %s aged %d
%s Info: error %d in selling product %s""" %(tm, product, price, user, age,tm,errorcode,product)

def get_errorcode(codes=(50,100,200,500,503,202)):
    return random.choice(codes)
    
def get_product(codes=("shirt", "pant", "ball", "bat")):
    return random.choice(codes)
    
def get_user(codes=("martin", "jack999", "jim", "teen")):
    return random.choice(codes)

def get_price(min=100,max=900):
    return random.randint(min,max)*1.0
    
def get_age(min=18,max=50):
    return random.randint(min,max)
    
#Sun Dec 20 20:16:27 2020
def get_time(count=2, before="seconds", format=r"%a %b %m %H:%M:%S %Y"): #before is dict
    #days, seconds, minutes, hours
    tm_dict = { "seconds" : 1, "minutes" : 1, "hours": 1,
                "days": 1  }
    delta = datetime.timedelta(**{before: tm_dict[before]})    
    start = datetime.datetime.today() - datetime.timedelta(**{before: count*tm_dict[before]})
    #print(delta, start)
    return [ (start + i*delta).strftime(format)  for i in range(count)]
    
#
def getfilepatterns(pattern, options=("(\\d+)", "%d"), index=1):
    parts = pattern.split("*")
    results = [parts.copy() for e in options]
    for i,e in enumerate(options):
        results[i][index:index] = options[i]
    return ["".join(res) for res in results]
    
    
def getfilename(path=os.path.join(os.path.dirname(__file__), "..", "logs"), fileglob="price*.log"):    
    #'price(\\d+).log', 'price%d.log'
    filepattern, filenametemplate = getfilepatterns(fileglob)
    nos = []
    for file in glob.glob(os.path.join(path, fileglob)):
        fname = os.path.basename(file)
        no = re.findall(filepattern, fname)
        nos.append(int(no[0]))
    maxno= max(nos) if nos else 0
    return filenametemplate % (maxno+1, )
    

    

if __name__ == '__main__':
    COUNT, BEFORE = getargs(options)    
    filename = os.path.join(os.path.dirname(__file__), "..", "logs",getfilename())
    with open(filename, "at") as f:
        print(f"Writing to {filename}")
        for i in get_time(count=COUNT, before=BEFORE):
            txt = template(i, get_product(), get_price(), get_user(), get_age(), get_errorcode())
            print(txt, file=f)